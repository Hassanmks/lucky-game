import fs from 'node:fs';
import path from 'node:path';

const resDir = path.resolve('android/app/src/main/res');
const manifestPath = path.resolve('android/app/src/main/AndroidManifest.xml');
const iconsSrcDir = path.resolve('resources/android-icons');

// 1. Lock MainActivity to portrait orientation
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  if (!manifest.includes('android:screenOrientation=')) {
    manifest = manifest.replace(
      /<activity\b/,
      '<activity\n            android:screenOrientation="portrait"'
    );
    fs.writeFileSync(manifestPath, manifest, 'utf8');
    console.log('Updated AndroidManifest.xml with portrait orientation.');
  }
}

// 2. Copy pre-generated crisp icons into all mipmap densities
if (fs.existsSync(iconsSrcDir)) {
  const densities = fs.readdirSync(iconsSrcDir);
  for (const density of densities) {
    const srcFolder = path.join(iconsSrcDir, density);
    if (!fs.statSync(srcFolder).isDirectory()) continue;
    const dstFolder = path.join(resDir, density);
    fs.mkdirSync(dstFolder, { recursive: true });
    for (const file of fs.readdirSync(srcFolder)) {
      fs.copyFileSync(path.join(srcFolder, file), path.join(dstFolder, file));
    }
  }
  console.log('Copied custom Lucky Game E-9999 launcher icons.');
}

// 3. Configure blue adaptive icon background & app theme colors
const valuesDir = path.join(resDir, 'values');
fs.mkdirSync(valuesDir, { recursive: true });

const icBgXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#0A5CB8</color>
</resources>
`;
fs.writeFileSync(path.join(valuesDir, 'ic_launcher_background.xml'), icBgXml, 'utf8');

const colorsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">#0A5CB8</color>
    <color name="colorPrimaryDark">#07418C</color>
    <color name="colorAccent">#F7C815</color>
</resources>
`;
fs.writeFileSync(path.join(valuesDir, 'colors.xml'), colorsXml, 'utf8');
console.log('Configured Android theme colors successfully.');
